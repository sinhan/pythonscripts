f=open('afile')
for lines in reversed(list(f)):
  print lines,

