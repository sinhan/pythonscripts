#!/usr/bin/python

from ex3 import print_args as g
g("three","four")
