with open('somefile.bin', 'wb') as f:
  f.write(b'Hello World')
